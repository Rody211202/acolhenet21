
/* =========================================================
   SELEÇÃO E MODO SIMPLIFICADO
   ========================================================= */
(function(){
  const chooser=document.getElementById("modeChooser");
  const normalBtn=document.getElementById("normalModeBtn");
  const seniorBtn=document.getElementById("seniorModeBtn");
  const changeBtn=document.getElementById("changeModeBtn");
  const inlineBtn=document.getElementById("activateSeniorInline");

  function setMode(mode){
    const senior=mode==="senior";
    document.body.classList.toggle("senior-mode",senior);
    localStorage.setItem("acolhenet-mode",mode);
    if(chooser) chooser.style.display="none";
    if(changeBtn){
      changeBtn.textContent=senior?"🧑 Modo padrão":"👴 Modo simplificado";
      changeBtn.setAttribute("aria-label",senior?"Voltar ao modo padrão":"Ativar modo simplificado");
    }
    if(senior) window.scrollTo({top:0,behavior:"smooth"});
  }

  function openChooser(){
    if(!chooser)return;
    chooser.style.display="flex";
  }

  normalBtn?.addEventListener("click",()=>setMode("normal"));
  seniorBtn?.addEventListener("click",()=>setMode("senior"));
  inlineBtn?.addEventListener("click",()=>setMode("senior"));
  changeBtn?.addEventListener("click",()=>{
    if(document.body.classList.contains("senior-mode")) setMode("normal");
    else openChooser();
  });

  // Primeira visita: mostra a escolha. Nas próximas, mantém a preferência.
  const saved=localStorage.getItem("acolhenet-mode");
  if(saved==="senior" || saved==="normal") setMode(saved);
  else if(chooser) chooser.style.display="flex";

  // Atalho de teclado útil para acessibilidade.
  document.addEventListener("keydown",e=>{
    if(e.key==="Escape" && chooser && chooser.style.display!=="none") setMode("normal");
  });
})();

const input=document.getElementById("imageInput");
const chooseBtn=document.getElementById("chooseBtn");
const dropZone=document.getElementById("dropZone");
const previewArea=document.getElementById("previewArea");
const previewImage=document.getElementById("previewImage");
const analyzeBtn=document.getElementById("analyzeBtn");
const removeBtn=document.getElementById("removeBtn");
const result=document.getElementById("result");
const newAnalysisBtn=document.getElementById("newAnalysisBtn");
const progress=document.getElementById("progress");
const progressText=document.getElementById("progressText");
const progressPercent=document.getElementById("progressPercent");
const barFill=document.getElementById("barFill");

function scrollToSection(id){document.getElementById(id)?.scrollIntoView({behavior:"smooth"});}
chooseBtn.onclick=()=>input.click();
input.onchange=()=>{if(input.files[0])showImage(input.files[0]);};

["dragenter","dragover"].forEach(e=>dropZone.addEventListener(e,ev=>{ev.preventDefault();dropZone.style.borderColor="#7659e8"}));
["dragleave","drop"].forEach(e=>dropZone.addEventListener(e,ev=>{ev.preventDefault();dropZone.style.borderColor="#cfc7ea"}));
dropZone.addEventListener("drop",ev=>{const f=ev.dataTransfer.files[0];if(f&&f.type.startsWith("image/"))showImage(f);});

function showImage(file){
 const reader=new FileReader();
 reader.onload=e=>{previewImage.src=e.target.result;previewArea.classList.remove("hidden");result.classList.add("hidden");dropZone.classList.add("hidden");};
 reader.readAsDataURL(file);
}

function normalize(t){return t.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"");}
function hasAny(text,words){return words.some(w=>text.includes(w));}

function analyzeText(raw){
 const t=normalize(raw).replace(/\s+/g," ").trim();
 const signals=[];
 let score=0;

 // Contextual rules: each alert needs evidence in the OCR text.
 const money=hasAny(t,["pix","transferencia","transfira","pagamento","pagar agora","deposito","depositar","boleto","chave pix","conta bancaria","dados bancarios"]);
 const credentials=hasAny(t,["senha","password","codigo de verificacao","codigo de seguranca","token","codigo sms","codigo recebido","cvc","cvv"]);
 const links=/(https?:\/\/|www\.)/.test(t)||hasAny(t,["clique no link","acesse o link","link abaixo","link de pagamento","url"]);
 const urgency=hasAny(t,["urgente","urgencia","agora","imediatamente","ultimas horas","ultima chance","prazo termina","faca agora","bloqueio hoje","sera bloqueado"]);
 const impersonation=hasAny(t,["banco","bancario","seguranca da conta","suporte","atendimento","receita federal","correios","mercado livre","mercado pago","paypal","whatsapp","instagram"]);
 const threat=hasAny(t,["sua conta sera bloqueada","conta sera bloqueada","conta foi bloqueada","perdeu acesso","vamos bloquear","seu cadastro sera cancelado"]);
 const prize=hasAny(t,["voce ganhou","parabens voce ganhou","premio","premiacao","sorteio","resgate seu premio","brinde gratis"]);

 if(credentials){signals.push(["🔑","Pedido de senha ou código","A conversa contém termos relacionados a senhas, códigos ou tokens. Não compartilhe esses dados."]);score+=3;}
 if(money){signals.push(["💸","Pedido ou referência a pagamento","A conversa contém termos ligados a Pix, transferência, pagamento ou dados bancários. Verifique por um canal oficial antes de pagar."]);score+=3;}
 if(links){signals.push(["🔗","Link ou endereço para acesso","Foi encontrado um link ou convite para acessar uma página. Não clique antes de confirmar o destino."]);score+=2;}
 if(urgency){signals.push(["🚨","Pressão ou urgência","A mensagem usa linguagem de urgência. Isso pode ser usado para impedir que a pessoa tenha tempo de verificar a informação."]);score+=1;}
 if(impersonation && (money||credentials||links||threat)){signals.push(["🏢","Possível personificação de serviço","Há referência a uma instituição ou serviço junto com outro sinal de alerta. Confirme diretamente no canal oficial."]);score+=2;}
 if(threat){signals.push(["⚠️","Ameaça de bloqueio ou perda de acesso","A mensagem menciona bloqueio, cancelamento ou perda de acesso. Não siga instruções sem verificar a origem."]);score+=2;}
 if(prize && (links||money)){signals.push(["🎁","Prêmio combinado com ação solicitada","Há referência a prêmio/sorteio junto com link ou pagamento. Isso merece verificação antes de qualquer ação."]);score+=2;}

 return {t,signals,score};
}

analyzeBtn.onclick=async()=>{
 if(!previewImage.src)return;
 progress.classList.remove("hidden");result.classList.add("hidden");
 progressText.textContent="Iniciando OCR...";
 progressPercent.textContent="0%";barFill.style.width="0%";
 analyzeBtn.disabled=true;

 try{
   const {data}=await Tesseract.recognize(previewImage.src,"por+eng",{
     logger:m=>{
       if(m.status==="recognizing text"){
         const p=Math.round((m.progress||0)*100);
         progressText.textContent="Lendo texto da imagem...";
         progressPercent.textContent=p+"%";barFill.style.width=p+"%";
       }
     }
   });
   const raw=data.text.trim();
   const a=analyzeText(raw);
   document.getElementById("ocrText").textContent=raw||"Nenhum texto legível foi identificado.";
   const signalsEl=document.getElementById("signals");

   if(!raw || raw.length<8){
     document.getElementById("resultBadge").textContent="SEM TEXTO";
     document.getElementById("resultTitle").textContent="Não foi possível identificar texto suficiente";
     document.getElementById("resultIntro").textContent="A imagem pode não conter uma conversa ou o texto pode estar pequeno, borrado ou difícil de ler.";
     signalsEl.innerHTML="";
     document.getElementById("recommendationText").textContent="Envie um print mais nítido e com o texto maior. Uma imagem sem texto não será classificada automaticamente como golpe.";
   }else if(a.signals.length===0){
     document.getElementById("resultBadge").textContent="SEM ALERTAS CLAROS";
     document.getElementById("resultTitle").textContent="Não encontrei sinais claros de golpe";
     document.getElementById("resultIntro").textContent="O texto foi lido, mas as regras não encontraram padrões suficientes para gerar um alerta.";
     signalsEl.innerHTML='<div class="signal"><strong>✅ Nenhum padrão suspeito encontrado</strong><span>Isso não garante que a conversa seja segura; significa apenas que os padrões configurados não foram identificados.</span></div>';
     document.getElementById("recommendationText").textContent="Continue verificando links, pedidos de dinheiro e solicitações de dados. Em caso de dúvida, confirme diretamente com a pessoa ou instituição por um canal conhecido.";
   }else{
     document.getElementById("resultBadge").textContent=a.score>=6?"ALERTA":"ATENÇÃO";
     document.getElementById("resultTitle").textContent=a.score>=6?"Vários sinais merecem atenção":"Alguns sinais merecem atenção";
     document.getElementById("resultIntro").textContent="Os alertas abaixo foram gerados a partir de palavras e padrões encontrados no texto do print. Eles não confirmam, sozinhos, que seja um golpe.";
     signalsEl.innerHTML=a.signals.map(s=>`<div class="signal"><strong>${s[0]} ${s[1]}</strong><span>${s[2]}</span></div>`).join("");
     document.getElementById("recommendationText").textContent="Não envie dinheiro, senhas ou códigos e não clique em links suspeitos. Confirme a situação pelo site, aplicativo ou telefone oficial da instituição ou pessoa envolvida.";
   }
   progress.classList.add("hidden");result.classList.remove("hidden");result.scrollIntoView({behavior:"smooth",block:"center"});
 }catch(err){
   progress.classList.add("hidden");
   alert("Não foi possível executar o OCR. Verifique sua conexão e tente novamente.");
   console.error(err);
 }finally{analyzeBtn.disabled=false;}
};

function reset(){input.value="";previewImage.src="";previewArea.classList.add("hidden");result.classList.add("hidden");progress.classList.add("hidden");dropZone.classList.remove("hidden");}
removeBtn.onclick=reset;newAnalysisBtn.onclick=reset;
// Interação da seção Golpes em destaque
document.addEventListener("DOMContentLoaded",()=>{const box=document.getElementById("golpe-details"),title=document.getElementById("golpe-detail-title"),content=document.getElementById("golpe-detail-content");if(!box)return;const data={pix:["Falso pedido de PIX",["Pressão para pagar imediatamente.","Ameaça de bloqueio ou problema na conta.","Pedido inesperado de dinheiro."],"Não faça o PIX pela mensagem. Confirme a situação em um canal oficial."],banco:["Falso suporte bancário",["Pessoa se apresenta como banco.","Pedido de senha, token ou código SMS.","Tentativa de criar urgência ou medo."],"Não informe senhas ou códigos. Procure o banco pelo aplicativo ou site oficial."],premio:["Prêmio ou sorteio falso",["Prêmio inesperado.","Pedido para clicar em um link.","Possível pedido de pagamento ou dados."],"Verifique o sorteio em um canal oficial antes de clicar ou enviar informações."],entrega:["Falso problema na entrega",["Problema urgente com uma entrega.","Link para atualizar dados.","Pedido de pagamento ou informações pessoais."],"Confira o pedido diretamente no aplicativo ou site oficial da loja ou transportadora."]};document.querySelectorAll(".golpe-btn").forEach(b=>b.addEventListener("click",()=>{const d=data[b.dataset.golpe];title.textContent=d[0];content.innerHTML='<div class="detail-columns"><div><h4>⚠️ Sinais de alerta</h4><ul>'+d[1].map(x=>'<li>'+x+'</li>').join('')+'</ul></div><div class="detail-action"><h4>🛡️ O que fazer</h4><p>'+d[2]+'</p></div></div><p class="detail-note">Exemplo fictício para fins educativos. Um sinal isolado não confirma um golpe.</p>';box.hidden=false;box.scrollIntoView({behavior:"smooth",block:"center"})}));document.getElementById("close-golpe")?.addEventListener("click",()=>box.hidden=true)});
