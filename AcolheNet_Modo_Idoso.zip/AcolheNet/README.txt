ACOLHENET — OCR + REGRAS

Esta versão substitui a resposta fixa por uma análise em duas etapas:

1. Tesseract.js faz OCR do print e extrai o texto.
2. JavaScript normaliza o texto e procura padrões específicos:
   - senha/código/token
   - Pix/pagamento/transferência
   - links
   - urgência
   - ameaça de bloqueio
   - personificação de serviços
   - prêmios combinados com link/pagamento

IMPORTANTE:
- O sistema NÃO considera qualquer imagem como golpe.
- Uma imagem sem texto suficiente não recebe alerta de golpe.
- Uma conversa sem os padrões configurados recebe "Não encontrei sinais claros de golpe".
- Um alerta não confirma que existe golpe.
- O OCR roda no navegador nesta versão.
- Tesseract.js é carregado por CDN, portanto é necessária internet para abrir a biblioteca na primeira vez.

Privacidade:
Peça ao usuário para esconder nome, telefone, CPF, endereço e outras informações pessoais antes de enviar o print.
